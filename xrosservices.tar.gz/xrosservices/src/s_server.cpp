#include "ros/ros.h"
#include <std_srvs/SetBool.h>
#include <iostream>

bool SetStatus(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{
 std::cout<<"catch(clt->srv): "<<(req.data?"1":"0")<<(res.success?"1":"0")<<(res.message.length()?res.message:"NULL")<<std::endl;
 ///Servrer側：requestへの入力は無効  
 req.data=false;///無効
 res.success=true;
 res.message="success";

 return true;
}


int main(int argc, char **argv)
{
  ros::init(argc, argv, "pos_server");
  ros::NodeHandle n;


  ros::ServiceServer server = n.advertiseService("test_service", SetStatus);

  ROS_INFO("Ready to serve set_pos.");
  ros::spin();

  return 0;
}
