#include "ros/ros.h"
#include "turtlesim/TeleportAbsolute.h"
#include <std_srvs/SetBool.h>
#include <iostream>

///rosrun sample1_1 set_pos turtle1/teleport_absolute:=/set_pos

int main(int argc, char **argv)
{
  ros::init(argc, argv, "set_pos");

  ros::NodeHandle n;

  ros::ServiceClient client = n.serviceClient<std_srvs::SetBool>("test_service");

  std_srvs::SetBool srv;
  srv.request.data = true;
  ///Client側：responseへの入力は無効  
  srv.response.message = "true";///無効

  if (client.call(srv))
  {
    // we can use srv.response (but in this case, it's void)
    std::cout<<"ack(srv->clt): "<<(srv.request.data?"1":"0")<<(srv.response.success?"1":"0")<<
		(srv.response.message.length()?srv.response.message:"NULL")<<std::endl;
    ROS_INFO("Succeed");
 
  }
  else
  {
    ROS_ERROR("Failed");
    return 1;
  }
  return 0;
}


