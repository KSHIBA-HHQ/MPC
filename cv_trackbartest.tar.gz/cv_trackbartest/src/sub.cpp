#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <opencv2/highgui/highgui.hpp>
#include <cv_bridge/cv_bridge.h>
#include <iostream>
#include <std_srvs/SetBool.h>

char response[30][32];
bool SetBeginStatus00(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[ 0];return true;}
bool SetBeginStatus01(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[ 1];return true;}
bool SetBeginStatus02(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[ 2];return true;}
bool SetBeginStatus03(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[ 3];return true;}
bool SetBeginStatus04(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[ 4];return true;}
bool SetBeginStatus05(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[ 5];return true;}
bool SetBeginStatus06(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[ 6];return true;}
bool SetBeginStatus07(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[ 7];return true;}
bool SetBeginStatus08(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[ 8];return true;}
bool SetBeginStatus09(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[ 9];return true;}

bool SetBeginStatus10(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[10];return true;}
bool SetBeginStatus11(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[11];return true;}
bool SetBeginStatus12(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[12];return true;}
bool SetBeginStatus13(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[13];return true;}
bool SetBeginStatus14(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[14];return true;}
bool SetBeginStatus15(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[15];return true;}
bool SetBeginStatus16(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[16];return true;}
bool SetBeginStatus17(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[17];return true;}
bool SetBeginStatus18(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[18];return true;}
bool SetBeginStatus19(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
{printf("catch");	res.success=true;res.message=response[19];return true;}


//bool SetBeginStatus20(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
//{printf("catch");	res.success=true;res.message=response[20];return true;}
//bool SetBeginStatus21(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
//{printf("catch");	res.success=true;res.message=response[21];return true;}
//bool SetBeginStatus22(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
//{printf("catch");	res.success=true;res.message=response[22];return true;}
//bool SetBeginStatus23(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
//{printf("catch");	res.success=true;res.message=response[23];return true;}
//bool SetBeginStatus24(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
//{printf("catch");	res.success=true;res.message=response[24];return true;}
//bool SetBeginStatus25(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
//{printf("catch");	res.success=true;res.message=response[25];return true;}
//bool SetBeginStatus26(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
//{printf("catch");	res.success=true;res.message=response[26];return true;}
//bool SetBeginStatus27(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
//{printf("catch");	res.success=true;res.message=response[27];return true;}
//bool SetBeginStatus28(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
//{printf("catch");	res.success=true;res.message=response[28];return true;}
//bool SetBeginStatus29(std_srvs::SetBool::Request  &req, std_srvs::SetBool::Response &res)
//{printf("catch");	res.success=true;res.message=response[29];return true;}


int main(int argc, char** argv)
{
  ros::init(argc, argv, "truck_bar_sub");
  ros::NodeHandle nh;
#define NUM_IMG   20
#define WITH_SRV	false

  int n=0;
  std::string title[NUM_IMG];
  std::string bar[NUM_IMG];
  cv::Mat img[NUM_IMG];
  int val[NUM_IMG];

  ros::ServiceServer server[NUM_IMG];
  int m=0;
  for(n=0;n<NUM_IMG;n++)
  {
	
	char buf[256];
	sprintf(buf,"/static_image%02d",n);   		
	title[n]=buf;
	sprintf(buf,"bar%02d",n);
	bar[n]=buf;
	val[n]=n;

	//if(argc==1)continue;
	cv::namedWindow(title[n],CV_WINDOW_NORMAL);
	cv::createTrackbar(bar[n],title[n],&val[n],NUM_IMG);

	int r=((m%3)==0)?255:0;
	int g=((m%3)==1)?255:0;
	int b=((m%3)==2)?255:0;
        img[n]=cv::Mat(60, 320, CV_8UC3,cv::Scalar(r,g,b));
	cv::imshow(title[n],img[n]);
	m++;
  }  
#if  WITH_SRV
server[ 0]= nh.advertiseService("bar00", SetBeginStatus00);
server[ 1]= nh.advertiseService("bar01", SetBeginStatus01);
server[ 2]= nh.advertiseService("bar02", SetBeginStatus02);
server[ 3]= nh.advertiseService("bar03", SetBeginStatus03);
server[ 4]= nh.advertiseService("bar04", SetBeginStatus04);
server[ 5]= nh.advertiseService("bar05", SetBeginStatus05);
server[ 6]= nh.advertiseService("bar06", SetBeginStatus06);
server[ 7]= nh.advertiseService("bar07", SetBeginStatus07);
server[ 8]= nh.advertiseService("bar08", SetBeginStatus08);
server[ 9]= nh.advertiseService("bar09", SetBeginStatus09);
server[10]= nh.advertiseService("bar10", SetBeginStatus10);
server[11]= nh.advertiseService("bar11", SetBeginStatus11);
server[12]= nh.advertiseService("bar12", SetBeginStatus12);
server[13]= nh.advertiseService("bar13", SetBeginStatus13);
server[14]= nh.advertiseService("bar14", SetBeginStatus14);
server[15]= nh.advertiseService("bar15", SetBeginStatus15);
server[16]= nh.advertiseService("bar16", SetBeginStatus16);
server[17]= nh.advertiseService("bar17", SetBeginStatus17);
server[18]= nh.advertiseService("bar18", SetBeginStatus18);
server[19]= nh.advertiseService("bar19", SetBeginStatus19);
//server[20]= nh.advertiseService("bar20", SetBeginStatus20);
//server[21]= nh.advertiseService("bar21", SetBeginStatus21);
//server[22]= nh.advertiseService("bar22", SetBeginStatus22);
//server[23]= nh.advertiseService("bar23", SetBeginStatus23);
//server[24]= nh.advertiseService("bar24", SetBeginStatus24);
//server[25]= nh.advertiseService("bar25", SetBeginStatus25);
//server[26]= nh.advertiseService("bar26", SetBeginStatus26);
//server[27]= nh.advertiseService("bar27", SetBeginStatus27);
//server[28]= nh.advertiseService("bar28", SetBeginStatus28);
//server[29]= nh.advertiseService("bar29", SetBeginStatus29);
#endif

  cv::waitKey(100);
  struct timespec startTime, endTime;
  clock_gettime(CLOCK_REALTIME, &startTime);  
  
  while (nh.ok()) 
  {
    ros::spinOnce();
    clock_gettime(CLOCK_REALTIME, &endTime);  
    printf("経過実時間 = ");
    if (endTime.tv_nsec < startTime.tv_nsec) {
      printf("%10ld.%09ld\n", endTime.tv_sec - startTime.tv_sec - 1
          ,endTime.tv_nsec + 1000000000 - startTime.tv_nsec);
    } else {
      printf("%10ld.%09ld\n", endTime.tv_sec - startTime.tv_sec
          ,endTime.tv_nsec - startTime.tv_nsec);
    }     
    startTime=endTime;

	printf("TrackBar");
	for(n=0;n< NUM_IMG ;n++)
	{
	 #if  WITH_SRV
	   val[n]=cv::getTrackbarPos(bar[n],title[n]);
	   sprintf(response[n],"%d",val[n]);
	 #else
	   ros::param::set(bar[n],cv::getTrackbarPos(bar[n],title[n]));
	 #endif
	   printf(" %02d",val[n]);  
	}
	printf(" \n"); 
	cv::waitKey(1);
  }
}

