#include <ros/ros.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include "std_srvs/SetBool.h"

int main(int argc, char** argv)
{
  ros::init(argc, argv, "truck_bar_main");
  ros::NodeHandle nh;
#define NUM_IMG   20
#define WITH_SRV	false

  int n=0;
  std::string title[NUM_IMG];
  std::string bar[NUM_IMG];
  cv::Mat img[NUM_IMG];
  int val[NUM_IMG];
  int m=0;


  ros::ServiceClient client[NUM_IMG];
  std_srvs::SetBool srv[NUM_IMG];
  for(n=0;n<NUM_IMG;n++)
  {
	char buf[256];
	sprintf(buf,"/static_image%02d",n);   		
	title[n]=buf;
	sprintf(buf,"bar%02d",n);
	bar[n]=buf;
	val[n]=n;
	#if WITH_SRV
	client[n] = nh.serviceClient<std_srvs::SetBool>(bar[n]);
	#endif

	if(argc==1)continue;
	cv::namedWindow(title[n],CV_WINDOW_NORMAL);
	cv::createTrackbar(bar[n],title[n],&val[n],NUM_IMG);

	int r=((m%3)==0)?255:0;
	int g=((m%3)==1)?255:0;
	int b=((m%3)==2)?255:0;
        img[n]=cv::Mat(60, 320, CV_8UC3,cv::Scalar(r,g,b));
	cv::imshow(title[n],img[n]);
	m++;
  }  

  cv::waitKey(100);
  struct timespec startTime, endTime;
  clock_gettime(CLOCK_REALTIME, &startTime);  
  

  while (nh.ok()) 
  {
    ros::spinOnce();
    clock_gettime(CLOCK_REALTIME, &endTime);  
    printf("経過実時間 = ");
    if (endTime.tv_nsec < startTime.tv_nsec) {
      printf("%10ld.%09ld\n", endTime.tv_sec - startTime.tv_sec - 1
          ,endTime.tv_nsec + 1000000000 - startTime.tv_nsec);
    } else {
      printf("%10ld.%09ld\n", endTime.tv_sec - startTime.tv_sec
          ,endTime.tv_nsec - startTime.tv_nsec);
    }     
    startTime=endTime;
   if(argc!=1)
   {
	printf("TrackBarCV");
        for(n=0;n< NUM_IMG ;n++)
	{
	   m=cv::getTrackbarPos(bar[n],title[n]);
	   printf(" %02d",m);  
        }
        printf(" \n");  

        cv::waitKey(1);
   }
   if(argc==1)
   {
	printf("TrackBarGet");
        for(n=0;n< NUM_IMG ;n++)
	{
		#if  WITH_SRV
		if (client[n].call(srv[n])){
			m=-1;	
			if(srv[n].response.success==true){
				m=atoi(srv[n].response.message.c_str());
			}
		}
		#else
		 ros::param::get(bar[n],m);

		#endif

		//printf(" %s",bar[n].c_str());
		printf(" %02d",m);  
        }
        printf(" \n");  

   }
  }
}

