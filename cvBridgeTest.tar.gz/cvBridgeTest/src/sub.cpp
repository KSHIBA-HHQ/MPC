#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <opencv2/highgui/highgui.hpp>
#include <cv_bridge/cv_bridge.h>
#include <iostream>

#if 0
// Subscriber to bottom camera
image_transport::Subscriber sub;

// Time control
ros::Time lastTime;

void imageCallback(const sensor_msgs::ImageConstPtr& msg)
{
    try
    {
        // Get the msg image
        cv::Mat InImage;
        InImage = cv_bridge::toCvShare(msg,"bgr8" )->image;
//        InImage=cv_bridge::cvtColorForDisplay(cv_bridge::toCvShare(msg,"bgr8"))->imag$
        cv::imshow("view", InImage);
//        cv::waitKey(0);
    }
    catch (cv_bridge::Exception& e)
        {
            ROS_ERROR("Could not convert from '%s' to 'jpg'.", msg->encoding.c_str());
        }
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "image_listener");
	ros::NodeHandle nh;
	cv::namedWindow("view",CV_WINDOW_NORMAL);
	cv::startWindowThread();
	lastTime = ros::Time::now();
	image_transport::ImageTransport it(nh);
	sub = it.subscribe("/static_image", 1, imageCallback);
	// sub = it.subscribe("camera/image", 1, imageCallback,ros::VoidPtr(),image_transport::TransportHints("compressed"));
	ros::spin();
	cv::destroyWindow("view");
}


#else
#define NUM_IMG   10
void imageCallback(int n,const sensor_msgs::ImageConstPtr& msg)
{
    try
    {
        cv::Mat InImage;
        InImage = cv_bridge::toCvShare(msg,"bgr8" )->image;
	char buf[256];
	sprintf(buf,"view%02d",n);        
	cv::imshow(buf, InImage);
	printf("%s\n",buf);
	cv::waitKey(1);
    }
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("Could not convert from '%s' to 'jpg'.", msg->encoding.c_str());
    }
}
void imageCallback00(const sensor_msgs::ImageConstPtr& msg)
{    imageCallback(0,msg);}
void imageCallback01(const sensor_msgs::ImageConstPtr& msg)
{    imageCallback(1,msg);}
void imageCallback02(const sensor_msgs::ImageConstPtr& msg)
{    imageCallback(2,msg);}
void imageCallback03(const sensor_msgs::ImageConstPtr& msg)
{    imageCallback(3,msg);}
void imageCallback04(const sensor_msgs::ImageConstPtr& msg)
{    imageCallback(4,msg);}
void imageCallback05(const sensor_msgs::ImageConstPtr& msg)
{    imageCallback(5,msg);}
void imageCallback06(const sensor_msgs::ImageConstPtr& msg)
{    imageCallback(6,msg);}
void imageCallback07(const sensor_msgs::ImageConstPtr& msg)
{    imageCallback(7,msg);}
void imageCallback08(const sensor_msgs::ImageConstPtr& msg)
{    imageCallback(8,msg);}
void imageCallback09(const sensor_msgs::ImageConstPtr& msg)
{    imageCallback(9,msg);}


int main(int argc, char **argv)
{
	ros::init(argc, argv, "image_listener");
	ros::NodeHandle nh;

	image_transport::ImageTransport it(nh);
	int n;
	std::string title[NUM_IMG];
	for(n=0;n<NUM_IMG ;n++){	
		char buf[256];
		//sprintf(buf,"view%02d",n);
		//cv::namedWindow(buf,CV_WINDOW_NORMAL);
	
		sprintf(buf,"/static_image%02d",n);
		title[n]=buf;   		
	}
	image_transport::Subscriber sub[NUM_IMG];
	//cv::startWindowThread();

sub[0]= it.subscribe(title[0], 1, imageCallback00);
sub[1]= it.subscribe(title[1], 1, imageCallback01);
sub[2]= it.subscribe(title[2], 1, imageCallback02);
sub[3]= it.subscribe(title[3], 1, imageCallback03);
sub[4]= it.subscribe(title[4], 1, imageCallback04);
sub[5]= it.subscribe(title[5], 1, imageCallback05);
sub[6]= it.subscribe(title[6], 1, imageCallback06);
sub[7]= it.subscribe(title[7], 1, imageCallback07);
sub[8]= it.subscribe(title[8], 1, imageCallback08);
sub[9]= it.subscribe(title[9], 1, imageCallback09);

	ros::spin();

	for(n=0;n<NUM_IMG ;n++){	
		char buf[256];
		sprintf(buf,"view%02d",n);
		cv::destroyWindow(buf);
	}

}
#endif

