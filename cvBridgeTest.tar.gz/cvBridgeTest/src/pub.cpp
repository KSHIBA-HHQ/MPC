#include <ros/ros.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>

#if 0
int main(int argc, char** argv)
{
  ros::init(argc, argv, "image_publisher");
  ros::NodeHandle nh;
 
    cv_bridge::CvImage cv_image[3];
    cv_image[0].image= cv::imread("/home/uda/konan.jpg",CV_LOAD_IMAGE_COLOR);
    cv_image[1].image= cv::Mat(240, 320, CV_8UC3,cv::Scalar(0,0,255));
    cv_image[2].image= cv::Mat(240, 320, CV_8UC1,cv::Scalar(255));

    cv_image[0].encoding = "bgr8";
    cv_image[1].encoding = "bgr8";
    cv_image[2].encoding = "mono8";

    sensor_msgs::Image pub_image[3];
    
    cv_image[0].toImageMsg(pub_image[0]);
    cv_image[1].toImageMsg(pub_image[1]);
    cv_image[2].toImageMsg(pub_image[2]);

  ros::Publisher pub = nh.advertise<sensor_msgs::Image>("/static_image", 1);
  ros::Rate rate(5);

  int n=0;
  while (nh.ok()) 
  {
    pub.publish(pub_image[n%3]);
    n++;
   // rate.sleep();
  }
}
#else
int main(int argc, char** argv)
{
  ros::init(argc, argv, "image_publisher");
  ros::NodeHandle nh;
#define NUM_IMG   10

  int n=0;
  ros::Publisher pub[NUM_IMG];
  std::string title[NUM_IMG];
  for(n=0;n<NUM_IMG;n++)
  {
	char buf[256];
	sprintf(buf,"/static_image%02d",n);   		
	pub[n]= nh.advertise<sensor_msgs::Image>(buf, 1);

	sprintf(buf,"view%02d",n);
	cv::namedWindow(buf,CV_WINDOW_NORMAL);
	title[n]=buf;
  }  

  int m=0;
  struct timespec startTime, endTime;
  clock_gettime(CLOCK_REALTIME, &startTime);  
  
  while (nh.ok()) 
  {
    clock_gettime(CLOCK_REALTIME, &endTime);  
    printf("経過実時間 = ");
    if (endTime.tv_nsec < startTime.tv_nsec) {
      printf("%10ld.%09ld\n", endTime.tv_sec - startTime.tv_sec - 1
          ,endTime.tv_nsec + 1000000000 - startTime.tv_nsec);
    } else {
      printf("%10ld.%09ld\n", endTime.tv_sec - startTime.tv_sec
          ,endTime.tv_nsec - startTime.tv_nsec);
    }     
    startTime=endTime;

    for(n=0;n< NUM_IMG ;n++){
        cv_bridge::CvImage cv_image;
	int r=((m%3)==0)?255:0;
	int g=((m%3)==1)?255:0;
	int b=((m%3)==2)?255:0;
	m++;
        sensor_msgs::Image pub_image;
        cv_image.image=cv::Mat(240, 320, CV_8UC3,cv::Scalar(r,g,b));
        cv_image.encoding = "bgr8";

	if(argc==1){        
		cv_image.toImageMsg(pub_image);
		pub[n].publish(pub_image);
	}else 	imshow(title[n],cv_image.image);
   
   }
    cv::waitKey(1);
  }
}

#endif
