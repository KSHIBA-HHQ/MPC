#include <ros/ros.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>

int main(int argc, char** argv)
{
  ros::init(argc, argv, "image_publisher");
  ros::NodeHandle nh;
 
    cv_bridge::CvImage cv_image[3];
    cv_image[0].image= cv::imread("/home/uda/konan.jpg",CV_LOAD_IMAGE_COLOR);
    cv_image[1].image= cv::Mat(240, 320, CV_8UC3,cv::Scalar(0,0,255));
    cv_image[2].image= cv::Mat(240, 320, CV_8UC1,cv::Scalar(255));

    cv_image[0].encoding = "bgr8";
    cv_image[1].encoding = "bgr8";
    cv_image[2].encoding = "mono8";

    sensor_msgs::Image pub_image[3];
    
    cv_image[0].toImageMsg(pub_image[0]);
    cv_image[1].toImageMsg(pub_image[1]);
    cv_image[2].toImageMsg(pub_image[2]);

  ros::Publisher pub = nh.advertise<sensor_msgs::Image>("/static_image", 1);
  ros::Rate rate(5);

  int n=0;
  while (nh.ok()) 
  {
    pub.publish(pub_image[n%3]);
    n++;
    rate.sleep();
  }
}
